

# Seventh

A lean Promises and Async lib for ES6/ES7.

* License: MIT
* Current status: alpha
* Platform: Node.js

It comes with a standard Promise implementation, with additional utilities (forEach, map, reduce, filter)
and a set of decorators to do the job (once, timeout, retry, debounce, serialize, promisify node function and api).

