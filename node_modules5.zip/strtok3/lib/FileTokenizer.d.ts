/// <reference types="node" />
import { AbstractTokenizer } from './AbstractTokenizer';
import { IFileInfo, IReadChunkOptions } from './types';
export declare class FileTokenizer extends AbstractTokenizer {
    private fd;
    constructor(fd: number, fileInfo: IFileInfo);
    /**
     * Read buffer from file
     * @param buffer
     * @param options - Read behaviour options
     * @returns Promise number of bytes read
     */
    readBuffer(buffer: Buffer, options?: IReadChunkOptions): Promise<number>;
    /**
     * Peek buffer from file
     * @param uint8Array - Uint8Array (or Buffer) to write data to
     * @param options - Read behaviour options
     * @returns Promise number of bytes read
     */
    peekBuffer(uint8Array: Uint8Array, options?: IReadChunkOptions): Promise<number>;
    close(): Promise<void>;
}
export declare function fromFile(sourceFilePath: string): Promise<FileTokenizer>;
