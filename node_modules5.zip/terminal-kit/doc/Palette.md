
<a name="top"></a>
<a name="ref.Palette"></a>
## Palette

A *Palette* instance is used by the 8-bit [ScreenBuffer](ScreenBuffer.md#top) to map 8-bit colors or even true colors.

TODOC
