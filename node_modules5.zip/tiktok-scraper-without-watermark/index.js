const { musicallydown, ssstik, keeptiktok } = require('./src/function')

exports.musicallydown = musicallydown
exports.ssstik = ssstik
exports.keeptiktok = keeptiktok