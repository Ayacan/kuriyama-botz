'use strict'

module.exports = require('./index.js')()
