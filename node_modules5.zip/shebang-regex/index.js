'use strict';
module.exports = /^#!(.*)/;
