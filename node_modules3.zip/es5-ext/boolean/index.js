"use strict";

module.exports = { isBoolean: require("./is-boolean") };
