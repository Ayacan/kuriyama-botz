"use strict";

module.exports = require("./is-implemented")()
	? String.prototype[require("es6-symbol").iterator]
	: require("./shim");
