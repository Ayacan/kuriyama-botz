module.exports = require('./toPairs');
