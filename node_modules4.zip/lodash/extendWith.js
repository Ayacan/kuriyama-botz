module.exports = require('./assignInWith');
