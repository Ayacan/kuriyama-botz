module.exports = require('./assignIn');
