module.exports = require('./lib/bash');
