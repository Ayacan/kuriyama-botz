module.exports = {
	format: {},
	autodetect: []
}
