export { parseDocument as parse } from 'htmlparser2';
export { default as render } from 'dom-serializer';
//# sourceMappingURL=htmlparser2-adapter.d.ts.map